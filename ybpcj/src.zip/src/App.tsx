import '@lark-base-open/js-sdk/dist/style/dashboard.css';
import './App.scss';
import './locales/i18n';
import 'dayjs/locale/zh-cn';
import 'dayjs/locale/en';
import * as React from 'react';
import { useState, useEffect, useMemo, useCallback } from 'react';
import { dashboard, bitable, DashboardState, FieldType } from '@lark-base-open/js-sdk';
import type { ITable, IField } from '@lark-base-open/js-sdk';
import { Button, Select, Checkbox, Spin, Empty, Toast, Tooltip } from '@douyinfe/semi-ui';
import { useTheme, useConfig } from './hooks';
import { useTranslation } from 'react-i18next';
import classnames from 'classnames';
import dayjs from 'dayjs';

// ==================== 类型定义 ====================

/**
 * 里程碑节点状态枚举
 */
enum MilestoneStatus {
  COMPLETED = 'completed',  // 已完成
  OVERDUE = 'overdue',      // 超时未完成
  OVERDUE_COMPLETED = 'overdue_completed', // 逾期已完成
  NORMAL = 'normal',        // 正常未完成
}

/**
 * 字段元数据接口
 */
interface FieldMeta {
  id: string;
  name: string;
  type: FieldType;
}

/**
 * 里程碑配置接口（存储在 customConfig 中）
 */
interface IMilestoneConfig {
  tableId: string;
  nameFieldId: string;
  planStartFieldId: string;
  planEndFieldId: string;
  actualEndFieldId: string;
  selectedMilestones: string[];
  customOrder: string[];
}

/**
 * 里程碑数据接口
 */
interface IMilestone {
  id: string;
  name: string;
  planStart: number;
  planEnd: number;
  actualEnd: number | null;
  status: MilestoneStatus;
}

/**
 * 飞书富文本片段接口
 */
interface FeishuTextSegment {
  type: string;
  text: string;
}

// ==================== 工具函数 ====================

/**
 * 从飞书字段值中提取文本内容
 * 支持多种格式：字符串、富文本对象、富文本数组
 */
const extractText = (value: any): string => {
  if (!value) return '';

  // 字符串直接返回
  if (typeof value === 'string') {
    return value;
  }

  // 富文本数组
  if (Array.isArray(value)) {
    return value
      .map((segment: FeishuTextSegment) => {
        if (segment && segment.type === 'text' && segment.text) {
          return segment.text;
        }
        return '';
      })
      .join('');
  }

  // 富文本对象
  if (typeof value === 'object' && value !== null) {
    if (value.text) {
      return value.text;
    }
    if (value.content && Array.isArray(value.content)) {
      return extractText(value.content);
    }
  }

  return '';
};

/**
 * 增强的日期解析函数
 * 支持时间戳、多种日期字符串格式、中文日期
 */
const parseDateValue = (value: any): number | null => {
  if (!value) return null;

  // 数字时间戳（判断秒/毫秒）
  if (typeof value === 'number') {
    return value < 10000000000 ? value * 1000 : value;
  }

  // 字符串日期
  if (typeof value === 'string') {
    const trimmed = value.trim();
    let parsed = dayjs(trimmed);

    // 直接解析
    if (parsed.isValid()) {
      return parsed.valueOf();
    }

    // 替换点号为短横线
    const withDashes = trimmed.replace(/\./g, '-');
    parsed = dayjs(withDashes);
    if (parsed.isValid()) {
      return parsed.valueOf();
    }

    // 中文日期格式
    const chineseDateMatch = trimmed.match(/(\d{4})\s*年\s*(\d{1,2})\s*月\s*(\d{1,2})\s*日/);
    if (chineseDateMatch) {
      const [, year, month, day] = chineseDateMatch;
      parsed = dayjs(`${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`);
      if (parsed.isValid()) {
        return parsed.valueOf();
      }
    }
  }

  return null;
};

/**
 * 计算里程碑状态
 */
const calculateMilestoneStatus = (
  planEnd: number,
  actualEnd: number | null
): MilestoneStatus => {
  const now = Date.now();

  if (actualEnd) {
    // 有实际完成时间，判断是否逾期
    if (actualEnd > planEnd) {
      return MilestoneStatus.OVERDUE_COMPLETED;
    }
    return MilestoneStatus.COMPLETED;
  }

  // 未完成
  if (now > planEnd) {
    return MilestoneStatus.OVERDUE;
  }

  return MilestoneStatus.NORMAL;
};

/**
 * 获取状态文本
 */
const getStatusText = (status: MilestoneStatus, t: any): string => {
  switch (status) {
    case MilestoneStatus.COMPLETED:
      return t('status.completed') || '已完成';
    case MilestoneStatus.OVERDUE:
      return t('status.overdue') || '已逾期';
    case MilestoneStatus.OVERDUE_COMPLETED:
      return t('status.overdue.completed') || '逾期已完成';
    case MilestoneStatus.NORMAL:
      return t('status.normal') || '进行中';
    default:
      return '';
  }
};

// ==================== 主应用组件 ====================

export default function App() {
  const { t, i18n } = useTranslation();
  const { bgColor } = useTheme();

  // 默认配置
  const defaultConfig: IMilestoneConfig = {
    tableId: '',
    nameFieldId: '',
    planStartFieldId: '',
    planEndFieldId: '',
    actualEndFieldId: '',
    selectedMilestones: [],
    customOrder: [],
  };

  const [config, setConfig] = useState<IMilestoneConfig>(defaultConfig);
  const [isLoading, setIsLoading] = useState(false);

  // 判断仪表盘状态
  const isCreate = dashboard.state === DashboardState.Create;
  const isConfig = dashboard.state === DashboardState.Config || isCreate;
  const isFullScreen = dashboard.state === DashboardState.FullScreen;

  // 创建状态：重置配置
  useEffect(() => {
    if (isCreate) {
      setConfig(defaultConfig);
    }
  }, [isCreate, i18n.language]);

  // 配置更新回调
  const updateConfig = useCallback((res: any) => {
    const { customConfig } = res;
    if (customConfig) {
      console.log('[App] 更新配置:', customConfig);
      setConfig(customConfig as IMilestoneConfig);
      // 通知渲染完成
      setTimeout(() => {
        dashboard.setRendered();
      }, 3000);
    }
  }, []);

  // 使用配置 Hook
  useConfig(updateConfig);

  // 保存配置
  const handleSaveConfig = useCallback(() => {
    console.log('[App] 保存配置:', config);
    dashboard.saveConfig({
      customConfig: config as any,
      dataConditions: [], // 数据源配置，可扩展
    });
  }, [config]);

  return (
    <main
      style={{ backgroundColor: isFullScreen ? 'transparent' : bgColor }}
      className={classnames('timeline-main', {
        'timeline-config': isConfig,
        'timeline-fullscreen': isFullScreen,
      })}
    >
      <div className="timeline-content">
        {isConfig ? (
          <ConfigPanel
            config={config}
            setConfig={setConfig}
            isLoading={isLoading}
            setIsLoading={setIsLoading}
          />
        ) : (
          <TimelineView config={config} />
        )}
      </div>
      {isConfig && (
        <div className="timeline-footer">
          <Button
            theme="solid"
            onClick={handleSaveConfig}
            disabled={
              !config.tableId ||
              !config.nameFieldId ||
              !config.planStartFieldId ||
              !config.planEndFieldId
            }
          >
            {t('confirm')}
          </Button>
        </div>
      )}
    </main>
  );
}

// ==================== 配置面板组件 ====================

interface ConfigPanelProps {
  config: IMilestoneConfig;
  setConfig: React.Dispatch<React.SetStateAction<IMilestoneConfig>>;
  isLoading: boolean;
  setIsLoading: React.Dispatch<React.SetStateAction<boolean>>;
}

function ConfigPanel({ config, setConfig, isLoading, setIsLoading }: ConfigPanelProps) {
  const { t } = useTranslation();

  const [tables, setTables] = useState<Array<{ id: string; name: string }>>([]);
  const [fields, setFields] = useState<FieldMeta[]>([]);
  const [allMilestones, setAllMilestones] = useState<string[]>([]);

  const selectedTableId = useMemo(() => config.tableId, [config.tableId]);

  /**
   * 加载所有数据表
   * 使用 base.getTableList() API
   */
  useEffect(() => {
    const loadTables = async () => {
      try {
        console.log('[ConfigPanel] 开始加载表格列表...');
        const tableList = await bitable.base.getTableList();
        console.log('[ConfigPanel] 获取到表格数量:', tableList.length);

        const tableMetaList = await Promise.all(
          tableList.map(async (table: ITable) => {
            const meta = await table.getMeta();
            return { id: meta.id, name: meta.name };
          })
        );
        setTables(tableMetaList);
        console.log(`[ConfigPanel] ✓ 成功加载 ${tableMetaList.length} 个表格`);
      } catch (error) {
        console.error('[ConfigPanel] 加载表格失败:', error);
        Toast.error({
          content: t('load.table.failed') || '加载表格失败',
          duration: 3,
        });
      }
    };
    loadTables();
  }, [t]);

  /**
   * 加载选中表格的字段列表
   * 使用 base.getFieldList(tableId) API
   */
  useEffect(() => {
    if (!selectedTableId) {
      setFields([]);
      return;
    }

    const loadFields = async () => {
      try {
        setIsLoading(true);
        console.log(`[ConfigPanel] 开始加载表格字段，表格ID: ${selectedTableId}`);

        const table = await bitable.base.getTable(selectedTableId);
        const fieldList = await table.getFieldList();
        console.log(`[ConfigPanel] 获取到字段数量: ${fieldList.length}`);

        const fieldMetaList: FieldMeta[] = await Promise.all(
          fieldList.map(async (field: IField) => {
            const meta = await field.getMeta();
            const type = await field.getType();
            return { id: meta.id, name: meta.name, type };
          })
        );

        // 过滤支持的字段类型（文本、日期、公式）
        const supportedTypes = [
          FieldType.Text,
          FieldType.DateTime,
          FieldType.Number,
          FieldType.Formula,
        ];
        const filteredFields = fieldMetaList.filter(field =>
          supportedTypes.includes(field.type)
        );
        setFields(filteredFields);
        console.log(`[ConfigPanel] ✓ 成功加载 ${filteredFields.length} 个可用字段`);
      } catch (error) {
        console.error('[ConfigPanel] 加载字段失败:', error);
        Toast.error({
          content: t('load.field.failed') || '加载字段失败',
          duration: 3,
        });
      } finally {
        setIsLoading(false);
      }
    };

    loadFields();
  }, [selectedTableId, setIsLoading, t]);

  /**
   * 加载里程碑名称列表（用于筛选器）
   */
  useEffect(() => {
    if (!selectedTableId || !config.nameFieldId) {
      setAllMilestones([]);
      return;
    }

    const loadMilestoneNames = async () => {
      try {
        console.log(`[ConfigPanel] 开始加载里程碑名称，字段ID: ${config.nameFieldId}`);
        const table = await bitable.base.getTable(selectedTableId);
        const response = await table.getRecords({ pageSize: 100 });

        console.log(`[ConfigPanel] 获取到 ${response.records.length} 条记录`);

        const names = response.records
          .map((record: any) => {
            const rawValue = record.fields[config.nameFieldId];
            return extractText(rawValue);
          })
          .filter((name: string): name is string => !!name)
          .filter(
            (value: string, index: number, self: string[]) =>
              self.indexOf(value) === index
          );

        setAllMilestones(names);
        console.log(`[ConfigPanel] ✓ 提取到 ${names.length} 个里程碑名称`);
      } catch (error) {
        console.error('[ConfigPanel] 加载里程碑失败:', error);
      }
    };

    loadMilestoneNames();
  }, [selectedTableId, config.nameFieldId]);

  /**
   * 获取日期类型字段选项
   */
  const getDateFieldOptions = useCallback(() => {
    return fields.filter(field => {
      if (field.type === FieldType.DateTime) return true;
      if (field.type === FieldType.Formula) return true;
      if (field.type === FieldType.Text) {
        const keywords = [
          '时间',
          '日期',
          'date',
          'time',
          '开始',
          '截止',
          '完成',
          'start',
          'end',
        ];
        return keywords.some(keyword =>
          field.name.toLowerCase().includes(keyword.toLowerCase())
        );
      }
      return false;
    });
  }, [fields]);

  /**
   * 获取文本类型字段选项
   */
  const getTextFieldOptions = useCallback(() => {
    return fields.filter(field => {
      if (field.type === FieldType.Text) return true;
      if (field.type === FieldType.Number) return true;
      return false;
    });
  }, [fields]);

  /**
   * 表格变更时重置相关配置
   */
  const handleTableChange = useCallback(
    (value: string | number | any[] | Record<string, any> | undefined) => {
      setConfig({
        ...config,
        tableId: String(value),
        nameFieldId: '',
        planStartFieldId: '',
        planEndFieldId: '',
        actualEndFieldId: '',
        selectedMilestones: [],
        customOrder: [],
      });
    },
    [config, setConfig]
  );

  /**
   * 名称字段变更时重置筛选器
   */
  const handleNameFieldChange = useCallback(
    (value: string | number | any[] | Record<string, any> | undefined) => {
      setConfig({
        ...config,
        nameFieldId: String(value),
        selectedMilestones: [],
      });
    },
    [config, setConfig]
  );

  return (
    <div className="config-panel">
      <Spin spinning={isLoading} size="large">
        <div className="config-form">
          {/* 数据表选择 */}
          <div className="form-item">
            <label className="form-label">{t('select.table')}</label>
            <Select
              placeholder={t('placeholder.table')}
              value={config.tableId}
              onChange={handleTableChange}
              optionList={tables.map(table => ({
                label: table.name,
                value: table.id,
              }))}
              className="form-select"
              filter
            />
          </div>

          {/* 里程碑名称字段 */}
          <div className="form-item">
            <label className="form-label">{t('select.name.field')}</label>
            <Select
              placeholder={t('placeholder.field')}
              value={config.nameFieldId}
              onChange={handleNameFieldChange}
              optionList={getTextFieldOptions().map(field => ({
                label: field.name,
                value: field.id,
              }))}
              className="form-select"
              disabled={!config.tableId}
              filter
            />
          </div>

          {/* 计划开始时间字段 */}
          <div className="form-item">
            <label className="form-label">{t('select.plan.start.field')}</label>
            <Select
              placeholder={t('placeholder.date.field')}
              value={config.planStartFieldId}
              onChange={(value: string | number | any[] | Record<string, any> | undefined) =>
                setConfig({ ...config, planStartFieldId: String(value) })
              }
              optionList={getDateFieldOptions().map(field => ({
                label: field.name,
                value: field.id,
              }))}
              className="form-select"
              disabled={!config.tableId}
              filter
            />
          </div>

          {/* 计划完成时间字段 */}
          <div className="form-item">
            <label className="form-label">{t('select.plan.end.field')}</label>
            <Select
              placeholder={t('placeholder.date.field')}
              value={config.planEndFieldId}
              onChange={(value: string | number | any[] | Record<string, any> | undefined) =>
                setConfig({ ...config, planEndFieldId: String(value) })
              }
              optionList={getDateFieldOptions().map(field => ({
                label: field.name,
                value: field.id,
              }))}
              className="form-select"
              disabled={!config.tableId}
              filter
            />
          </div>

          {/* 实际完成时间字段（可选） */}
          <div className="form-item">
            <label className="form-label">
              {t('select.actual.end.field')}（可选）
            </label>
            <Select
              placeholder={t('placeholder.date.field')}
              value={config.actualEndFieldId}
              onChange={(value: string | number | any[] | Record<string, any> | undefined) =>
                setConfig({ ...config, actualEndFieldId: value ? String(value) : '' })
              }
              optionList={getDateFieldOptions().map(field => ({
                label: field.name,
                value: field.id,
              }))}
              className="form-select"
              disabled={!config.tableId}
              filter
              showClear
            />
          </div>

          {/* 里程碑筛选器 */}
          {allMilestones.length > 0 && (
            <div className="form-item">
              <label className="form-label">{t('filter.milestones')}</label>
              <div className="checkbox-group">
                <Checkbox.Group
                  value={config.selectedMilestones}
                  onChange={(values: string[]) =>
                    setConfig({ ...config, selectedMilestones: values })
                  }
                >
                  {allMilestones.map(name => (
                    <div key={name} className="checkbox-item">
                      <Checkbox value={name}>{name}</Checkbox>
                    </div>
                  ))}
                </Checkbox.Group>
              </div>
              <div className="filter-hint">
                {t('filter.hint', {
                  count: config.selectedMilestones.length,
                  total: allMilestones.length,
                })}
              </div>
            </div>
          )}

          {/* 配置提示 */}
          {!config.tableId && (
            <div className="config-tip">{t('config.tip')}</div>
          )}
        </div>
      </Spin>
    </div>
  );
}

// ==================== 时间线展示组件 ====================

interface TimelineViewProps {
  config: IMilestoneConfig;
}

function TimelineView({ config }: TimelineViewProps) {
  const [milestones, setMilestones] = useState<IMilestone[]>([]);
  const [loading, setLoading] = useState(true);
  const [draggedItem, setDraggedItem] = useState<string | null>(null);
  const { t } = useTranslation();

  /**
   * 加载里程碑数据
   * 展示态使用 getData() API
   */
  const loadMilestones = useCallback(async () => {
    if (
      !config.tableId ||
      !config.nameFieldId ||
      !config.planStartFieldId ||
      !config.planEndFieldId
    ) {
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      console.log('[TimelineView] 开始加载里程碑数据');

      const table = await bitable.base.getTable(config.tableId);
      const response = await table.getRecords({ pageSize: 100 });

      console.log(`[TimelineView] 从表格读取到 ${response.records.length} 条记录`);

      // 解析每条记录
      const milestoneList: IMilestone[] = response.records
        .map(record => {
          // 提取名称
          const nameRaw = record.fields[config.nameFieldId];
          const name = extractText(nameRaw);

          // 提取时间
          const planStartRaw = record.fields[config.planStartFieldId];
          const planEndRaw = record.fields[config.planEndFieldId];
          const actualEndRaw = config.actualEndFieldId
            ? record.fields[config.actualEndFieldId]
            : null;

          const planStart = parseDateValue(planStartRaw);
          const planEnd = parseDateValue(planEndRaw);
          const actualEnd = config.actualEndFieldId
            ? parseDateValue(actualEndRaw)
            : null;

          // 应用筛选器
          if (config.selectedMilestones.length > 0 && !config.selectedMilestones.includes(name)) {
            return null;
          }

          // 检查必需字段
          if (!name || !planStart || !planEnd) {
            return null;
          }

          // 计算状态
          const status = calculateMilestoneStatus(planEnd, actualEnd);

          return {
            id: record.recordId,
            name,
            planStart,
            planEnd,
            actualEnd,
            status,
          };
        })
        .filter((m): m is IMilestone => m !== null);

      console.log(`[TimelineView] ✓ 解析出 ${milestoneList.length} 条有效数据`);

      // 排序：优先使用自定义顺序，否则按计划开始时间
      if (config.customOrder && config.customOrder.length > 0) {
        milestoneList.sort((a, b) => {
          const indexA = config.customOrder.indexOf(a.id);
          const indexB = config.customOrder.indexOf(b.id);
          if (indexA !== -1 && indexB !== -1) return indexA - indexB;
          if (indexA !== -1) return -1;
          if (indexB !== -1) return 1;
          return a.planStart - b.planStart;
        });
      } else {
        milestoneList.sort((a, b) => a.planStart - b.planStart);
      }

      setMilestones(milestoneList);

      // 无数据提示
      if (milestoneList.length === 0) {
        Toast.warning({
          content: t('no.data.description'),
          duration: 5,
        });
      }
    } catch (error) {
      console.error('[TimelineView] 加载里程碑数据失败:', error);
      Toast.error({
        content: t('load.data.failed') || '数据加载失败',
        duration: 5,
      });
    } finally {
      setLoading(false);
    }
  }, [config, t]);

  /**
   * 初始加载和配置变化时加载数据
   */
  useEffect(() => {
    loadMilestones();
  }, [loadMilestones]);

  /**
   * 监听数据变更（协同编辑）
   * 使用 onDataChange API
   */
  useEffect(() => {
    const offDataChange = dashboard.onDataChange(() => {
      console.log('[TimelineView] 数据发生变更，重新加载');
      loadMilestones();
    });

    return () => {
      offDataChange();
    };
  }, [loadMilestones]);

  /**
   * 拖拽开始
   */
  const handleDragStart = useCallback((e: React.DragEvent, id: string) => {
    setDraggedItem(id);
    e.dataTransfer.effectAllowed = 'move';
  }, []);

  /**
   * 拖拽悬停
   */
  const handleDragOver = useCallback(
    (e: React.DragEvent, targetId: string) => {
      e.preventDefault();
      if (draggedItem === null || draggedItem === targetId) return;

      const newMilestones = [...milestones];
      const draggedIndex = newMilestones.findIndex(m => m.id === draggedItem);
      const targetIndex = newMilestones.findIndex(m => m.id === targetId);

      if (draggedIndex !== -1 && targetIndex !== -1) {
        [newMilestones[draggedIndex], newMilestones[targetIndex]] = [
          newMilestones[targetIndex],
          newMilestones[draggedIndex],
        ];
        setMilestones(newMilestones);
      }
    },
    [draggedItem, milestones]
  );

  /**
   * 拖拽结束 - 保存自定义顺序
   */
  const handleDragEnd = useCallback(async () => {
    if (draggedItem) {
      const newOrder = milestones.map(m => m.id);
      console.log('[TimelineView] 拖拽排序，保存顺序:', newOrder);

      // 更新配置中的自定义顺序
      const updatedConfig = {
        ...config,
        customOrder: newOrder,
      };

      // 保存到仪表盘配置
      await dashboard.saveConfig({
        customConfig: updatedConfig as any,
        dataConditions: [],
      });
    }
    setDraggedItem(null);
  }, [draggedItem, milestones, config]);

  // 加载状态
  if (loading) {
    return (
      <div className="timeline-loading">
        <Spin size="large" />
        <div style={{ marginTop: '16px', color: 'var(--ccm-chart-N600)' }}>
          {t('loading') || '正在加载数据...'}
        </div>
      </div>
    );
  }

  // 无数据状态
  if (milestones.length === 0) {
    return (
      <div className="timeline-empty">
        <Empty title={t('no.data.title')} description={t('no.data.description')} />
      </div>
    );
  }

  return (
    <div className="horizontal-timeline-wrapper">
      <div className="horizontal-timeline">
        {/* 独立的灰色水平线条（全屏宽度，不被里程碑分割） */}
        <div className="timeline-continuous-line" />

        {/* 里程碑节点（绝对定位在线条上） */}
        {milestones.map((milestone, index) => (
          <Tooltip
            key={milestone.id}
            content={
              <div>
                <div>
                  <strong>{milestone.name}</strong>
                </div>
                <div>
                  {t('plan.end')}：{dayjs(milestone.planEnd).format('YYYY-MM-DD')}
                </div>
                {milestone.actualEnd && (
                  <div>
                    {t('actual.end')}：{dayjs(milestone.actualEnd).format('YYYY-MM-DD')}
                  </div>
                )}
                <div>
                  状态：{getStatusText(milestone.status, t)}
                </div>
              </div>
            }
          >
            <div
              className={classnames(
                'timeline-node-horizontal',
                `timeline-node-${milestone.status}`,
                {
                  'timeline-node-dragging': draggedItem === milestone.id,
                }
              )}
              draggable
              onDragStart={e => handleDragStart(e, milestone.id)}
              onDragOver={e => handleDragOver(e, milestone.id)}
              onDragEnd={handleDragEnd}
            >
              {/* 顶部标签 */}
              <div className="timeline-label-top">
                {milestone.name}
              </div>

              {/* 圆点（始终对齐在线条中心） */}
              <div className="timeline-dot-horizontal" />

              {/* 底部信息 */}
              <div className="timeline-info-bottom">
                <div className="timeline-status-text">
                  {getStatusText(milestone.status, t)}
                </div>
                {/* 计划完成时间 */}
                <div className="timeline-date-text">
                  {t('plan.end')}: {dayjs(milestone.planEnd).format('YYYY-MM-DD')}
                </div>
                {/* 实际完成时间：仅在已完成状态显示 */}
                {milestone.status === MilestoneStatus.COMPLETED && milestone.actualEnd && (
                  <div className="timeline-date-text">
                    {t('actual.end')}: {dayjs(milestone.actualEnd).format('YYYY-MM-DD')}
                  </div>
                )}
              </div>
            </div>
          </Tooltip>
        ))}
      </div>
    </div>
  );
}
